# Testing2 > 2025-02-10 12:58pm
https://universe.roboflow.com/robotics-vision/testing2-t4hdr-geolz

Provided by a Roboflow user
License: CC BY 4.0

